#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TASKS 100
#define TITLE_LEN 50
#define FILE_NAME "tasks.txt"

struct Task {
    char title[TITLE_LEN];
    int done; // 0 = not done, 1 = done
};

struct Task tasks[MAX_TASKS];
int taskCount = 0;

void loadTasks() {
    FILE *fp = fopen(FILE_NAME, "r");
    if (!fp) return; // no file yet
    while (fscanf(fp, "%49[^,],%d\n", tasks[taskCount].title, &tasks[taskCount].done) == 2) {
        taskCount++;
    }
    fclose(fp);
}

void saveTasks() {
    FILE *fp = fopen(FILE_NAME, "w");
    for (int i = 0; i < taskCount; i++) {
        fprintf(fp, "%s,%d\n", tasks[i].title, tasks[i].done);
    }
    fclose(fp);
}

void addTask() {
    if (taskCount >= MAX_TASKS) {
        printf("Task list full!\n");
        return;
    }
    printf("Enter task title: ");
    getchar(); // clear buffer
    fgets(tasks[taskCount].title, TITLE_LEN, stdin);
    tasks[taskCount].title[strcspn(tasks[taskCount].title, "\n")] = 0; // remove newline
    tasks[taskCount].done = 0;
    taskCount++;
    saveTasks();
    printf("Task added!\n");
}

void listTasks() {
    if (taskCount == 0) {
        printf("No tasks found.\n");
        return;
    }
    for (int i = 0; i < taskCount; i++) {
        printf("%d. [%c] %s\n", i + 1, tasks[i].done ? 'X' : ' ', tasks[i].title);
    }
}

void markDone() {
    int n;
    printf("Enter task number to mark done: ");
    scanf("%d", &n);
    if (n < 1 || n > taskCount) {
        printf("Invalid task number.\n");
        return;
    }
    tasks[n - 1].done = 1;
    saveTasks();
    printf("Task marked done!\n");
}

int main() {
    int choice;
    loadTasks();
    do {
        printf("\n--- Task Tracker ---\n");
        printf("1. Add Task\n");
        printf("2. List Tasks\n");
        printf("3. Mark Task Done\n");
        printf("0. Exit\n");
        printf("Choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1: addTask(); break;
            case 2: listTasks(); break;
            case 3: markDone(); break;
            case 0: printf("Goodbye!\n"); break;
            default: printf("Invalid choice!\n");
        }
    } while (choice != 0);
    return 0;
}