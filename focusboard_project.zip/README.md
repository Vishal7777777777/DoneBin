# FocusBoard - C Task Tracker

## Goal
A simple offline C-based task tracker that stores, lists, and updates tasks using file handling, structures, and arrays.

## Features
- Add new tasks
- View all tasks
- Mark tasks as done
- Stores tasks in `tasks.txt` for offline use

## How to Run
1. Compile the program:
   ```bash
   gcc focusboard.c -o focusboard
   ```
2. Run the program:
   ```bash
   ./focusboard
   ```

## Author
Your Name
